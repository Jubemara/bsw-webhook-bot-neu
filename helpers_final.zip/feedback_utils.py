
import requests
import os

def generiere_feedback_datei():
    return "feedback.jsonl"

def generiere_feedback_webhook():
    webhook_url = os.getenv("FEEDBACK_WEBHOOK")
    if not webhook_url:
        return "❌ Kein Webhook gesetzt"
    r = requests.post(webhook_url, headers={"Authorization": "Bearer TESTTOKEN"})
    return f"🔔 Webhook-Status: {r.status_code}"

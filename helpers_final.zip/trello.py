
import requests
import os
from dotenv import load_dotenv

load_dotenv("getkeys.env")

TRELLO_KEY = os.getenv("TRELLO_KEY")
TRELLO_TOKEN = os.getenv("TRELLO_TOKEN")
BOARD_ID = os.getenv("TRELLO_BOARD_ID")

def finde_liste_id(liste_name):
    url = f"https://api.trello.com/1/boards/{BOARD_ID}/lists"
    params = {"key": TRELLO_KEY, "token": TRELLO_TOKEN}
    r = requests.get(url, params=params)
    for l in r.json():
        if l['name'].strip().lower() == liste_name.strip().lower():
            return l['id']
    return None

def sende_karte_an_trello(titel, text, liste):
    list_id = finde_liste_id(liste)
    if not list_id:
        return f"❌ Liste '{liste}' nicht gefunden."
    url = "https://api.trello.com/1/cards"
    query = {
        'key': TRELLO_KEY,
        'token': TRELLO_TOKEN,
        'idList': list_id,
        'name': titel,
        'desc': text
    }
    r = requests.post(url, params=query)
    return f"✅ Trello-Karte erstellt: {r.status_code}"
